import React from 'react';

interface BrandLogoProps {
  theme?: 'dark' | 'light' | 'gold' | 'champagne';
  className?: string;
  size?: number; // width/height in px
  showText?: boolean;
  textPosition?: 'right' | 'bottom';
  textType?: 'full' | 'short';
}

export default function BrandLogo({
  theme = 'dark',
  className = '',
  size = 48,
  showText = false,
  textPosition = 'right',
  textType = 'short'
}: BrandLogoProps) {
  // Select color based on luxury theme
  const getColor = () => {
    switch (theme) {
      case 'dark':
        return '#FAFAFA'; // White/off-white for obsidian background
      case 'light':
        return '#181514'; // Obsidian/espresso for sand background
      case 'gold':
        return '#B39E8C'; // Signature Muted Taupe/Gold style
      case 'champagne':
        return '#D1C6BD'; // Sand/Champagne tone
      default:
        return '#FAFAFA';
    }
  };

  const color = getColor();

  // Custom high-precision paths modeled on the logo:
  // Sweep wings rising from bottom-left to top-right plus a 4-point glint star.
  return (
    <div className={`inline-flex items-center ${textPosition === 'bottom' ? 'flex-col space-y-3' : 'space-x-4'} ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 500 500"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-500 hover:scale-105"
      >
        {/* Sparkle Star at Top Right (approx 380, 80) */}
        <path
          d="M 380 40 Q 380 80 340 80 Q 380 80 380 120 Q 380 80 420 80 Q 380 80 380 40 Z"
          fill={color}
          className="animate-pulse"
          style={{ animationDuration: '3s' }}
        />

        {/* Top & Largest Sweeping Wing Layer */}
        <path
          d="M 124 457 C 150 370 210 240 332 120 C 375 78 418 43 451 16 C 432 90 381 210 320 290 C 260 368 185 425 124 457 Z"
          fill={color}
        />

        {/* Middle Wing Layer */}
        <path
          d="M 154 445 C 190 380 250 290 351 190 C 390 151 415 120 435 97 C 411 160 355 250 297 320 C 230 400 185 432 154 445 Z"
          fill={color}
          opacity="0.9"
        />

        {/* Bottom/Stabilizer Wing Layer */}
        <path
          d="M 190 432 C 240 392 285 340 348 275 C 375 247 398 220 417 195 C 392 250 340 330 285 385 C 230 430 210 433 190 432 Z"
          fill={color}
          opacity="0.8"
        />
      </svg>

      {showText && (
        <div className={`flex flex-col text-left ${textPosition === 'bottom' ? 'items-center text-center' : ''}`}>
          <span 
            className="font-serif text-lg tracking-[0.25em] font-light leading-none"
            style={{ color }}
          >
            {textType === 'short' ? 'S&CO+' : 'SOARITY & CO.'}
          </span>
          <span 
            className="font-sans text-[9px] tracking-[0.4em] uppercase opacity-60 mt-1 font-medium"
            style={{ color }}
          >
            Alta Costura Digital
          </span>
        </div>
      )}
    </div>
  );
}
