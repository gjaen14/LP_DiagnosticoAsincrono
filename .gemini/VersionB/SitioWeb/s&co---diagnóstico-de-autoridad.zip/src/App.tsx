import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, Shield, Award, Sparkles, AlertCircle, Quote, CheckCircle2, 
  HelpCircle, ChevronRight, Lock, ExternalLink, Calendar, Users, Cpu, FileText, Compass
} from 'lucide-react';
import BrandLogo from './components/BrandLogo';
import ThreeHeroBackground from './components/ThreeHeroBackground';
import AuthorityCalculator from './components/AuthorityCalculator';
import BookingForm from './components/BookingForm';

export default function App() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [selectedScore, setSelectedScore] = useState<number>(45);
  const [isScrolled, setIsScrolled] = useState(false);

  // Scroll effect on header
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const startBookingFlow = (score: number) => {
    setSelectedScore(score);
    setIsBookingOpen(true);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-brand-obsidian text-brand-white relative">
      
      {/* ────────────────────────────────────────────────────────
          FLOATING PREMIUM HEADER
          ──────────────────────────────────────────────────────── */}
      <header 
        className={`fixed top-0 left-0 right-0 z-40 transition-all duration-500 px-6 md:px-16 py-5 flex justify-between items-center ${
          isScrolled 
            ? 'bg-brand-obsidian/85 backdrop-blur-md border-b border-brand-taupe/15 shadow-xl' 
            : 'bg-transparent border-b border-white/5'
        }`}
      >
        <div className="cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <BrandLogo theme="gold" size={38} showText={true} />
        </div>

        {/* Sophisticated Editorial Nav Links */}
        <nav className="hidden md:flex items-center space-x-10 text-xs tracking-[0.2em] uppercase font-light text-brand-champagne/80">
          <button 
            onClick={() => scrollToSection('philosophy-section')} 
            className="hover:text-brand-taupe transition-colors duration-200 cursor-pointer"
          >
            Filosofía
          </button>
          <button 
            onClick={() => scrollToSection('tax-section')} 
            className="hover:text-brand-taupe transition-colors duration-200 cursor-pointer"
          >
            El Impuesto
          </button>
          <button 
            onClick={() => scrollToSection('calculator-section')} 
            className="hover:text-brand-taupe transition-colors duration-200 cursor-pointer"
          >
            Simulador
          </button>
          <button 
            onClick={() => scrollToSection('partners-section')} 
            className="hover:text-brand-taupe transition-colors duration-200 cursor-pointer"
          >
            Los Socios
          </button>
        </nav>

        {/* CTA */}
        <div>
          <button
            onClick={() => scrollToSection('calculator-section')}
            className="hidden sm:inline-block border border-brand-taupe/40 hover:border-brand-taupe hover:text-brand-taupe text-brand-white font-sans text-[10px] tracking-widest uppercase py-2.5 px-5 rounded-full transition-all duration-300"
          >
            Calcular Impuesto
          </button>
        </div>
      </header>

      {/* ────────────────────────────────────────────────────────
          HERO BANNER - THREEJS BACKDROP
          ──────────────────────────────────────────────────────── */}
      <section className="relative min-h-screen flex items-center justify-center pt-24 md:pt-0 overflow-hidden px-4">
        {/* ThreeJS Live Particle Wave & Coordinate Mesh Backdrop */}
        <ThreeHeroBackground />

        {/* Shadow Vignette for Editorial Low-Key Lighting */}
        <div className="absolute inset-0 bg-gradient-to-t from-brand-obsidian via-brand-obsidian/45 to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_40%,_#181514_90%)] pointer-events-none" />

        {/* Floating background code accents "Artesanía Digital" */}
        <div className="absolute left-8 bottom-12 hidden xl:block font-mono text-[9px] text-brand-taupe/20 space-y-1 select-none leading-relaxed">
          <p className="text-brand-taupe/35">// HAUTE COUTURE SYSTEM RESOLVER</p>
          <p>const brand = "S&CO" | "High-Ticket";</p>
          <p>const latencyFactor = computeVibeScore(prospectEngine);</p>
          <p>if (latencyFactor &lt; 90) &#123;</p>
          <p>&nbsp;&nbsp;throw new DesconfianzaTax(lostCredibilityInSeconds);</p>
          <p>&#125;</p>
        </div>

        <div className="absolute right-8 top-28 hidden xl:block font-serif text-[11px] text-brand-champagne/15 select-none text-right max-w-[170px] leading-relaxed italic">
          "Un ecosistema imperfecto anula la elocuencia de un especialista senior."
        </div>

        {/* Centered Typography - Alternating serif/sans and regular/italic */}
        <div className="relative z-10 text-center max-w-4xl mx-auto space-y-6 px-4">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="inline-flex items-center gap-2 bg-brand-brown/50 border border-brand-taupe/20 rounded-full px-4 py-1.5 text-xs text-brand-taupe hover:bg-brand-brown/85 transition-colors cursor-pointer"
            onClick={() => scrollToSection('product-focus')}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-brand-taupe animate-pulse" />
            <span className="font-sans text-[10px] tracking-widest uppercase font-medium">Diagnóstico de Autoridad Exclusivo</span>
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-serif text-4xl sm:text-5xl md:text-6xl text-brand-white tracking-tight leading-[1.1]"
          >
            Operas a nivel <span className="italic font-normal text-brand-taupe">Senior</span>,<br />
            pero tu ecosistema digital se ve <span className="italic font-normal opacity-85">Junior</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="font-sans text-sm sm:text-base md:text-lg text-brand-champagne/90 font-light max-w-2xl mx-auto leading-relaxed"
          >
            Estás pagando el <span className="text-brand-taupe font-medium">impuesto de la desconfianza</span>. Los clientes corporativos de élite regatean tus tarifas o eligen firmas menores por la fragilidad de tu fachada visual & técnica.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="pt-6 flex flex-col sm:flex-row gap-4 justify-center items-center font-sans"
          >
            <button
              onClick={() => scrollToSection('calculator-section')}
              className="w-full sm:w-auto bg-brand-taupe hover:bg-brand-taupe/90 text-brand-obsidian font-sans font-semibold tracking-wider text-xs uppercase py-4 px-8 rounded-xl transition-all duration-300 flex items-center justify-center gap-2.5 shadow-lg shadow-brand-taupe/10"
            >
              <span>Simular Diagnóstico Gratuito</span>
              <ArrowRight className="w-4 h-4 text-brand-obsidian" />
            </button>
            
            <button
              onClick={() => scrollToSection('philosophy-section')}
              className="w-full sm:w-auto hover:bg-brand-brown/45 text-brand-champagne font-sans font-medium tracking-wide text-xs py-4 px-8 rounded-xl transition-all duration-300 border border-brand-taupe/15"
            >
              Nuestra Filosofía
            </button>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            transition={{ duration: 1.5, delay: 1 }}
            className="pt-12 text-[10px] font-sans tracking-[0.25em] uppercase text-brand-champagne/60 font-light"
          >
            Exclusivo para Directores, Fundadores y Partners Ejecutivos
          </motion.div>
        </div>

        {/* Animated Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 cursor-pointer opacity-40 hover:opacity-100 transition-opacity" onClick={() => scrollToSection('philosophy-section')}>
          <div className="w-[1px] h-12 bg-gradient-to-b from-brand-taupe to-transparent mx-auto flex justify-center">
            <span className="w-1.5 h-1.5 rounded-full bg-brand-taupe animate-pulse" />
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────
          PHILOSOPHY SECTION ("ALTA COSTURA Meets Tech")
          ──────────────────────────────────────────────────────── */}
      <section id="philosophy-section" className="py-20 md:py-32 px-6 md:px-16 container mx-auto max-w-6xl relative">
        <div className="absolute left-0 top-1/2 -translate-y-1/2 w-64 h-64 bg-brand-taupe/5 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Column Text */}
          <div className="lg:col-span-7 space-y-6 text-left">
            <span className="font-sans text-xs tracking-[0.4em] uppercase text-brand-taupe font-semibold">
              01 // Manifiesto de Postura
            </span>
            <h2 className="font-serif text-3xl md:text-5xl text-brand-white tracking-tight leading-tight">
              Sin estética imponente, el gran <span className="italic font-normal text-brand-taupe">talento técnico</span> se reduce a una mercancía barata.
            </h2>
            <p className="font-sans text-sm text-brand-champagne/80 font-light leading-relaxed">
              El moodboard de nuestra firma fusiona dos mundos: la elocuencia de un periódico vintage impreso y tazas de terracota hechas a mano, con el frío rigor del código de programación escrito en iPads comerciales.
            </p>
            <p className="font-sans text-sm text-brand-champagne/80 font-light leading-relaxed">
              En el mercado premium de servicios corporativos B2B, tus prospectos no compran tu código o tu tiempo de consultoría; compran la <strong>certeza de tu autoridad</strong>. Cuando tu presentación digital es lenta, desbalanceada estéticamente, o utiliza plantillas mediocres de WordPress, sufres el impuesto implícito de la negociación difícil.
            </p>
          </div>

          {/* Right Column Visual (The Vintage Coffee cup on iPad visualizer mockup) */}
          <div className="lg:col-span-5 bg-brand-brown/40 border border-brand-taupe/15 backdrop-blur-md rounded-2xl p-8 relative overflow-hidden flex flex-col justify-between min-h-[350px]">
            <div className="absolute top-0 right-0 w-24 h-24 bg-brand-taupe/10 rounded-full blur-xl" />
            
            <div className="font-mono text-[10px] text-brand-taupe/65 space-y-1 border-b border-brand-taupe/10 pb-4 mb-4">
              <span>// SOARITY COUTURIES SPEC</span>
              <h2>"Digital High-End Blueprint"</h2>
            </div>

            <div className="my-auto space-y-6 relative z-10">
              <div className="flex gap-4 items-center">
                <div className="p-3 bg-brand-obsidian rounded-xl text-brand-taupe border border-brand-taupe/20">
                  <Compass className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-sans text-xs tracking-wider uppercase font-bold text-brand-white">Alineación Milimétrica</h4>
                  <p className="font-sans text-xs text-brand-champagne/60 font-light">Estructura limpia, micro-márgenes y tipografías perfectamente calibradas.</p>
                </div>
              </div>

              <div className="flex gap-4 items-center">
                <div className="p-3 bg-brand-obsidian rounded-xl text-brand-taupe border border-brand-taupe/20">
                  <Cpu className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-sans text-xs tracking-wider uppercase font-bold text-brand-white">Desempeño Letal</h4>
                  <p className="font-sans text-xs text-brand-champagne/60 font-light">Eliminamos las plantillas infladas por código React de máxima velocidad.</p>
                </div>
              </div>
            </div>

            <p className="font-serif text-xs text-brand-champagne/70 italic leading-relaxed pt-4 border-t border-brand-taupe/10 mt-4">
              "No hacemos diseño convencional; esculpimos credibilidad comercial para consultoras de alto vuelo."
            </p>
          </div>

        </div>
      </section>

      {/* ────────────────────────────────────────────────────────
          THE JUNIOR VS SENIOR CONTRAST (The Pain Hook)
          ──────────────────────────────────────────────────────── */}
      <section id="tax-section" className="py-20 md:py-32 bg-brand-brown/30 relative">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom,_var(--tw-gradient-stops))] from-brand-taupe/5 via-transparent to-transparent pointer-events-none" />

        <div className="px-6 md:px-16 container mx-auto max-w-5xl">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="font-sans text-xs tracking-[0.4em] uppercase text-brand-taupe font-semibold">
              02 // El Gran Mismatch
            </span>
            <h2 className="font-serif text-3xl md:text-5xl text-brand-white tracking-tight leading-tight mt-3">
              ¿Por qué te regatean o eligen a competidores peores?
            </h2>
            <p className="font-sans text-sm text-brand-champagne/80 font-light mt-4">
              Cuando la calidad de tu entrega técnica es Senior pero tu empaque web se ve Junior, generas un vacío cognitivo que tus clientes corporativos llenan con desconfianza.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch font-sans">
            
            {/* Junior Facade Box */}
            <div className="bg-brand-obsidian/60 border border-red-950/40 rounded-2xl p-6 md:p-8 flex flex-col justify-between space-y-6 transition-all duration-300 hover:border-red-900/40">
              <div>
                <div className="w-8 h-8 rounded-full bg-red-950/30 border border-red-900/40 text-red-400 flex items-center justify-center font-bold text-xs mb-4">
                  ✗
                </div>
                <h4 className="font-serif text-lg text-brand-white tracking-wide mb-3">La Fachada Digital Junior</h4>
                <p className="text-xs text-brand-champagne/80 font-light leading-relaxed mb-4">
                  Tu ecosistema está plagado de detalles que restan credibilidad a nivel subconsciente:
                </p>
                <ul className="space-y-3.5 text-xs text-brand-champagne/70 font-light pl-4 list-disc marker:text-red-900">
                  <li>Estructuras tipográficas robóticas y desorganizadas que gritan "comprado en ThemeForest".</li>
                  <li>Lentitud en la carga web de más de 3 segundos (el cliente piensa: 'si así es su web, cómo cuidarán mi sistema').</li>
                  <li>Inconsistencia de colores o imágenes genéricas libres de regalías (Shutterstock-vibe) sin personalidad técnica ni misterio.</li>
                  <li>Formulario rígido sin elocuencia ni un proceso de entrada selectivo.</li>
                </ul>
              </div>
              <div className="bg-red-950/20 text-red-300 border border-red-900/20 rounded-xl p-3 text-center text-[11px] uppercase tracking-wider font-semibold">
                Consecuencia: Objección por Precios Altos
              </div>
            </div>

            {/* Senior Facade Box */}
            <div className="bg-brand-brown/50 border border-brand-taupe/20 rounded-2xl p-6 md:p-8 flex flex-col justify-between space-y-6 transition-all duration-300 hover:border-brand-taupe/40">
              <div>
                <div className="w-8 h-8 rounded-full bg-brand-taupe/20 border border-brand-taupe/40 text-brand-taupe flex items-center justify-center font-bold text-xs mb-4">
                  ✓
                </div>
                <h4 className="font-serif text-lg text-brand-white tracking-wide mb-3">La Postura de Autoridad S&CO</h4>
                <p className="text-xs text-brand-champagne/80 font-light leading-relaxed mb-4">
                  El cliente experimenta un embudo de alta gama que blinda tus tarifas corporativas desde la entrada:
                </p>
                <ul className="space-y-3.5 text-xs text-brand-champagne/70 font-light pl-4 list-disc marker:text-brand-taupe">
                  <li>Uso magistral de tipografía clásica (Playfair Display) y amplios márgenes (negativismo relajado).</li>
                  <li>Desarrollo puristas de alto rendimiento (carga instantánea de menos de 1 segundo).</li>
                  <li>Paletas cromáticas sombrías hechas a medida, inspiradas en marcas de lujo, metales finos y cueros profundos.</li>
                  <li>Un embudo boutique que obliga al cliente a solicitar acceso, invirtiendo la dinámica del cazador y la presa.</li>
                </ul>
              </div>
              <div className="bg-brand-taupe/15 text-brand-taupe border border-brand-taupe/30 rounded-xl p-3 text-center text-[11px] uppercase tracking-wider font-semibold">
                Consecuencia: Postura de Socio Exclusivo
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────
          CALCULATOR CONTAINER SECTION (SIMULATOR)
          ──────────────────────────────────────────────────────── */}
      <section className="bg-brand-obsidian">
        <AuthorityCalculator onStartBooking={startBookingFlow} />
      </section>

      {/* ────────────────────────────────────────────────────────
          THE STRATEGIC PARTNERS (Jheisry + Gustavo)
          ──────────────────────────────────────────────────────── */}
      <section id="partners-section" className="py-20 md:py-32 px-6 md:px-16 container mx-auto max-w-5xl relative">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-sans text-xs tracking-[0.4em] uppercase text-brand-taupe font-semibold">
            03 // Dúo de Especialidad
          </span>
          <h2 className="font-serif text-3xl md:text-5xl text-brand-white tracking-tight leading-tight mt-3">
            Elegancia Visual & Rigor Técnico
          </h2>
          <p className="font-sans text-sm text-brand-champagne/80 font-light mt-4">
            Al agendar tu Diagnóstico de Autoridad, no serás auditado por juniors ni personal comercial. Te sientas personalmente con dos socios que viven el estándar premium de entrega todos los días:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch font-sans">
          
          {/* Partner 1: Jheisry */}
          <div className="bg-brand-brown/40 border border-brand-taupe/15 rounded-2xl p-6 md:p-8 flex flex-col justify-between space-y-6">
            <div>
              <span className="font-mono text-[9px] text-brand-taupe tracking-widest uppercase block mb-1">
                La Estética & Postura
              </span>
              <h3 className="font-serif text-2xl text-brand-white mb-2">Jheisry</h3>
              <p className="text-xs text-brand-taupe tracking-widest uppercase font-semibold mb-4">
                Brand Strategist
              </p>
              <p className="text-xs text-brand-champagne/85 font-light leading-relaxed mb-3">
                Especialista en curar identidades y relato para agencias de alto valor. Su trabajo es asegurar que tu diseño web, tu documentación y tu paleta transmitan un valor indomable a las salas de decisiones corporativas.
              </p>
              <blockquote className="border-l border-brand-taupe/30 pl-3 italic text-[11px] text-brand-champagne/70 font-light">
                "La elocuencia visual actúa como un filtro subconsciente. Tu cliente ya decidió si pagará tu tarifa premium antes de leer la propuesta."
              </blockquote>
            </div>
            <div className="bg-brand-obsidian/45 rounded-xl p-3 text-[10px] text-brand-champagne/60 font-mono tracking-wider uppercase flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-brand-taupe" />
              Especialidad: Alquimia Editorial & Luxury Brand Rules
            </div>
          </div>

          {/* Partner 2: Gustavo */}
          <div className="bg-brand-brown/40 border border-brand-taupe/15 rounded-2xl p-6 md:p-8 flex flex-col justify-between space-y-6">
            <div>
              <span className="font-mono text-[9px] text-brand-taupe tracking-widest uppercase block mb-1">
                La Arquitectura & Rigor
              </span>
              <h3 className="font-serif text-2xl text-brand-white mb-2">Gustavo</h3>
              <p className="text-xs text-brand-taupe tracking-widest uppercase font-semibold mb-4">
                Socio Técnico (Engineering Lead)
              </p>
              <p className="text-xs text-brand-champagne/85 font-light leading-relaxed mb-3">
                Garante de que tu plataforma digital esté programada a mano con la velocidad, pulcritud y seguridad de un traje a medida. Destruye la latencia técnica que desvaloriza a las firmas de IT senior a ojos de compras.
              </p>
              <blockquote className="border-l border-brand-taupe/30 pl-3 italic text-[11px] text-brand-champagne/70 font-light">
                "Los ecosistemas lentos e inestables son una falta de respeto al tiempo del cliente corporativo. La ingeniería limpia es el mayor lujo digital."
              </blockquote>
            </div>
            <div className="bg-brand-obsidian/45 rounded-xl p-3 text-[10px] text-brand-champagne/60 font-mono tracking-wider uppercase flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-brand-taupe" />
              Especialidad: Código React Puro, Micro-márgenes & Velocidad Extrema
            </div>
          </div>

        </div>
      </section>

      {/* ────────────────────────────────────────────────────────
          PRODUCT OVERVIEW & BOOKING CONVERSION GRID ("EL DIAGNÓSTICO")
          ──────────────────────────────────────────────────────── */}
      <section id="product-focus" className="py-20 md:py-32 bg-brand-brown/20 relative border-t border-b border-brand-taupe/10">
        <div className="px-6 md:px-16 container mx-auto max-w-4xl text-center">
          
          <div className="max-w-2xl mx-auto space-y-4 mb-12">
            <span className="font-sans text-xs tracking-[0.4em] uppercase text-brand-taupe font-semibold block">
              Inversión S&co
            </span>
            <h2 className="font-serif text-3xl md:text-5xl text-brand-white tracking-tight leading-tight">
              Asegura tu ranura para el <span className="italic font-normal text-brand-taupe">Diagnóstico</span>
            </h2>
            <p className="font-sans text-sm text-brand-champagne/80 font-light leading-relaxed max-w-lg mx-auto">
              Adquiere una hora de escrutinio técnico y visual directo. No hay informes automatizados de bots; Gustavo y Jheisry ingresarán a tus sistemas y deconstruirán tu empaque visual en vivo.
            </p>
          </div>

          <div className="bg-brand-brown/60 border border-brand-taupe/35 backdrop-blur-md rounded-2xl max-w-2xl mx-auto p-8 relative overflow-hidden flex flex-col md:flex-row justify-between items-center text-left gap-8">
            <div className="absolute top-0 right-0 w-32 h-32 bg-brand-taupe/5 rounded-full blur-2xl pointer-events-none" />

            <div className="space-y-4">
              <div>
                <span className="font-sans text-[10px] tracking-widest uppercase text-brand-taupe font-bold block mb-1">
                  Sesión en Vivo (1 Hora)
                </span>
                <h3 className="font-serif text-2xl text-brand-white leading-none">
                  Diagnóstico de Autoridad
                </h3>
              </div>
              <ul className="space-y-2 font-sans text-xs text-brand-champagne/80 font-light">
                <li className="flex items-center gap-2.5">
                  <span className="text-brand-taupe">✦</span> Análisis forense de deck comercial & UI externa.
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="text-brand-taupe">✦</span> Evaluación de latencia Core Web Vitals & Arquitectura.
                </li>
                <li className="flex items-center gap-2.5">
                  <span className="text-brand-taupe">✦</span> Estrategia de blindaje y defensa de tarifas $15K+.
                </li>
              </ul>
              
              <div className="flex gap-2 items-center text-[10px] font-sans text-brand-champagne/50">
                <Lock className="w-3.5 h-3.5 text-brand-taupe" />
                <span>Cobro único. Reembolso total si no detectamos fugas críticas.</span>
              </div>
            </div>

            <div className="border-t md:border-t-0 md:border-l border-brand-taupe/20 pt-6 md:pt-0 md:pl-10 text-center md:text-right flex flex-col justify-center items-center md:items-end w-full md:w-auto">
              <div className="mb-4">
                <span className="text-xs font-sans tracking-widest uppercase opacity-40 block">Inversión Única</span>
                <span className="font-serif text-4xl font-extrabold text-brand-white tracking-tight">
                  $250{' '}
                  <span className="text-xs font-sans tracking-widest uppercase text-brand-taupe font-normal">
                    USD
                  </span>
                </span>
              </div>

              <button
                onClick={() => startBookingFlow(selectedScore)}
                className="w-full md:w-auto bg-brand-taupe hover:bg-brand-taupe/90 active:scale-[0.98] text-brand-obsidian font-sans font-semibold tracking-wider text-xs uppercase py-4 px-8 rounded-xl transition-all duration-300 flex items-center justify-center gap-2"
              >
                <span>Agendar Ahora</span>
                <ArrowRight className="w-4 h-4 text-brand-obsidian" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-2xl mx-auto mt-12 font-sans text-xs text-brand-champagne/60 font-light">
            <div className="bg-brand-brown/20 p-4 rounded-xl border border-brand-taupe/10 text-center">
              Ninguna herramienta automatizada imita el criterio humano senior.
            </div>
            <div className="bg-brand-brown/20 p-4 rounded-xl border border-brand-taupe/10 text-center">
              Revisamos tu material de ventas confidencial a puerta cerrada.
            </div>
            <div className="bg-brand-brown/20 p-4 rounded-xl border border-brand-taupe/10 text-center">
              Garantía de Autoridad: Aportamos al menos 4 fugas concretas de dinero.
            </div>
          </div>

        </div>
      </section>

      {/* ────────────────────────────────────────────────────────
          TESTIMONIALS (Curated, Elegant Quotes)
          ──────────────────────────────────────────────────────── */}
      <section className="py-20 md:py-32 px-6 md:px-16 container mx-auto max-w-4xl relative">
        <div className="text-center mb-12">
          <Quote className="w-10 h-10 text-brand-taupe/40 mx-auto mb-3" />
          <span className="font-sans text-xs tracking-[0.4em] uppercase text-brand-taupe font-semibold">
            Prueba de Confianza
          </span>
        </div>

        <div className="bg-brand-brown/30 border border-brand-taupe/10 rounded-2xl p-8 md:p-12 text-center relative max-w-2xl mx-auto">
          <p className="font-serif text-base md:text-lg text-brand-white italic leading-relaxed mb-6">
            "Gustavo detectó tres fallos de latencias críticas en nuestro cargador que Jheisry bautizó como 'fugas de marca corporativa'. Estábamos comunicando debilidad a cuentas empresariales de $50k. Corregirlo nos permitió asegurar dos retenciones sin un solo descuento."
          </p>
          <div className="font-sans text-xs">
            <strong className="text-brand-taupe tracking-wider block font-semibold">Alejandro del Valle</strong>
            <span className="text-brand-champagne/60 font-light block">Socio Cofundador, Neotech Enterprise</span>
            <span className="text-brand-taupe/75 font-mono text-[10px] mt-2 inline-block px-2.5 py-0.5 rounded-full border border-brand-taupe/20 bg-brand-taupe/5">
              + $45,000 USD retenidos en Q1
            </span>
          </div>
        </div>
      </section>

      {/* ────────────────────────────────────────────────────────
          EDITORIAL FOOTER WITH S&CO+ EMBLEM
          ──────────────────────────────────────────────────────── */}
      <footer className="py-16 bg-brand-obsidian border-t border-brand-taupe/15 px-6 md:px-16">
        <div className="container mx-auto max-w-5xl flex flex-col md:flex-row justify-between items-center gap-8 text-center md:text-left">
          
          <div className="space-y-4">
            <BrandLogo theme="gold" size={42} showText={true} />
            <p className="font-sans text-xs text-brand-champagne/50 font-light max-w-xs leading-relaxed">
              Esculpiendo elocuencia visual y blindaje tecnológico para firmas consultoras y boutiques senior.
            </p>
          </div>

          <div className="space-y-2 font-sans text-xs text-brand-champagne/40">
            <div className="flex gap-6 justify-center md:justify-end text-brand-champagne/60">
              <span className="hover:text-brand-taupe transition-colors duration-200 cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
                Arriba
              </span>
              <span>//</span>
              <a href="mailto:soarityco@gmail.com" className="hover:text-brand-taupe transition-colors duration-200">
                soarityco@gmail.com
              </a>
            </div>
            <p className="text-[10px] font-mono mt-3">
              © {new Date().getFullYear()} Soarity & Co. Todos los derechos reservados. <br />
              Hecho a mano en Alta Costura Digital.
            </p>
          </div>

        </div>
      </footer>

      {/* ────────────────────────────────────────────────────────
          BOOKING CHECKOUT MODAL OVERLAY
          ──────────────────────────────────────────────────────── */}
      <AnimatePresence>
        {isBookingOpen && (
          <BookingForm 
            initialScore={selectedScore} 
            onClose={() => setIsBookingOpen(false)} 
          />
        )}
      </AnimatePresence>

    </div>
  );
}
